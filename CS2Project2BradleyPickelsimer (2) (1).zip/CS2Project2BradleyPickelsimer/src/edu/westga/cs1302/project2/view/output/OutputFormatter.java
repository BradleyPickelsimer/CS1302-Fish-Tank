package edu.westga.cs1302.project2.view.output;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import edu.westga.cs1302.project2.model.Fish;
import edu.westga.cs1302.project2.model.RoundFish;
import edu.westga.cs1302.project2.model.Tank;
import edu.westga.cs1302.project2.view.resources.UI;

/**
 * OutputFormatter builds summaries and reports for the fish tank.
 *
 * @author	CS1302
 * @version Spring 2022
 */
public class OutputFormatter {
	
	/**
	 * Initializes the OutputFormatter
	 */
	public OutputFormatter() {
	}
	
	/**
	 * Creates a report by analyzing a given fish tank.
	 * 
	 * @precondition 	theTank != null
	 * @postcondition 	none
	 *
	 * @param 	theTank		fish tank to analyze
	 * @return 	a report with the required items listed
	 */
	public String buildReport(Tank theTank) {
		if (theTank == null) {
			throw new IllegalArgumentException(UI.ExceptionMessages.NULL_TANK);
		}
		theTank.sortByWidth();
		int numberOfRoundFish = 0;
		int numberOfLongFish = 0;
		for (Fish fish : theTank.getFish()) {
			if (fish.getClass() == RoundFish.class) {
				numberOfRoundFish += 1;
			} else {
				numberOfLongFish += 1;
			}
		}
		
		String summary = "Tank Report:";
		summary += System.lineSeparator() + System.lineSeparator();
		summary += "Number of RoundFish: " + numberOfRoundFish + System.lineSeparator();
		summary += "Number of ElongatedFish: " + numberOfLongFish + System.lineSeparator() + System.lineSeparator();
		summary += "Smallest fish: " + this.getSmallestFish(theTank);
		summary += "Largest fish: " + this.getLargestFish(theTank) + System.lineSeparator();
		summary += "Fish in sorted order: " + System.lineSeparator();
		for (Fish fish : theTank.getFish()) {
			summary += fish.toString();
		}
		return summary;
	}
	
	private Fish getSmallestFish(Tank theTank) {
		Fish smallestFish = theTank.getFish().get(0);
		for (Fish fish : theTank.getFish()) {
			if (fish.getWidth() < smallestFish.getWidth()) {
				smallestFish = fish;
			}
		}
		return smallestFish;
	}
	
	private Fish getLargestFish(Tank theTank) {
		Fish largestFish = theTank.getFish().get(0);
		for (Fish fish : theTank.getFish()) {
			if (fish.getWidth() > largestFish.getWidth()) {
				largestFish = fish;
			}
		}
		return largestFish;
	}
}

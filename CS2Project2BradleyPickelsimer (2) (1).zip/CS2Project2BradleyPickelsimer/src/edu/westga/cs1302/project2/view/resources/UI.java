package edu.westga.cs1302.project2.view.resources;

/**
 * The Class UI defines output strings that are displayed for the user to see.
 * 
 * @author	CS1302
 * @version Spring 2022
 */
public final class UI {

	/**
	 * Defines string messages for exception messages for the fish tank animation.
	 */
	public static final class ExceptionMessages {
		public static final String NULL_TANK = "the tank cannot be null.";
	}

}

package edu.westga.cs1302.project2;

import edu.westga.cs1302.project2.model.Tank;
import edu.westga.cs1302.project2.model.manager.TankManager;
import edu.westga.cs1302.project2.view.output.OutputFormatter;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * The Class SkyAnimation.
 * 
 * @author CS1302
 * @version Spring 2022
 */

public class Main extends Application {

	private static final String TITLE = "Project 2 by Bradley Pickelsimer";
	private TankManager theTankManager = new TankManager();

	@Override
	public void start(Stage primaryStage) {

		Scene scene = this.setupGui();
		primaryStage.setScene(scene);
		primaryStage.setTitle(TITLE);
		primaryStage.show();

		AnimationTimer timer = this.setupAnimaterTImer();
		timer.start();

	}

	/**
	 * Setup gui.
	 *
	 * @return the scene
	 */
	private Scene setupGui() {
		Group root = new Group();
		Scene scene = new Scene(root, Tank.WIDTH, Tank.HEIGHT + 200);

		VBox vbox = new VBox();
		this.theTankManager.setupTank();
		vbox.getChildren().add(this.theTankManager);

		TextArea tankReport = new TextArea();
		tankReport.setMinHeight(200);
		tankReport.setEditable(false);
		OutputFormatter outputFormatter = new OutputFormatter();
		tankReport.setText(outputFormatter.buildReport(this.theTankManager.getTank()));

		vbox.getChildren().add(tankReport);
		root.getChildren().add(vbox);

		return scene;
	}

	/**
	 * Setup animationTimer.
	 *
	 * @return the animation timer
	 */
	private AnimationTimer setupAnimaterTImer() {
		AnimationTimer timer = new AnimationTimer() {
			private long lastUpdate = 0;

			@Override
			public void handle(long currentTime) {
				if (currentTime - this.lastUpdate >= 300000000) {
					this.lastUpdate = currentTime;
					Main.this.theTankManager.update();
				}
			}
		};
		return timer;
	}

	/**
	 * The main method - entry point for the program.
	 *
	 * @precondition none
	 * @postcondition none
	 * 
	 * @param args the arguments - not used
	 */
	public static void main(String[] args) {
		launch(args);
	}
}

package edu.westga.cs1302.project2.model;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * Defines a fish
 * @author Bradley Pickelsimer
 * @version 1.0
 */
public abstract class Fish extends Canvas implements Comparable<Fish>, Swimmer {

	private Direction direction;
	private double speed;
	protected Color color;
	
	/**
	 * Instantiates a new Fish
	 * 
	 * @precondition none
	 * @postcondition A new fish is created with the given characteristics
	 * 
	 * @param x is the xPos for the fish
	 * @param y is the yPos for the fish
	 * @param width is the width of the canvas
	 * @param height is the height of the canvas
	 */
	protected Fish(double x, double y, double width, double height, double speed, Color color) {
		super(width, height);
		this.setLayoutX(x);
		this.setLayoutY(y);
		this.direction = Direction.RIGHT;
		this.speed = speed;
		this.color = color;
	}
	
	/**
	 * Gets the speed of the fish
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return double speed is the speed of the fish
	 */
	
	public double getSpeed() {
		return this.speed;
	}
	
	/**
	 * Gets the direction the fish is facing
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the direction the fish is facing
	 */
	public Direction getDirection() {
		return this.direction;
	}
	
	/**
	 * Clears the canvas
	 * 
	 * @precondition none
	 * @postcondition this.canvas.isEmpty()
	 */
	public void clear() {
		GraphicsContext theGraphicsContext = this.getGraphicsContext2D();
		theGraphicsContext.clearRect(0,  0, this.getWidth(), this.getHeight());
	}
	
	/**
	 * Draws something on the canvas
	 * 
	 * @precondition none
	 * @postcondition the given thing is drawn on the canvas
	 */
	public void draw() {
		GraphicsContext gc = super.getGraphicsContext2D();
		this.drawBody(gc);
		this.setBlackFillAndStroke(gc);
		this.drawMouth(gc);
		this.drawFin(gc);
		this.drawEye(gc);
	}

	private void drawEye(GraphicsContext gc) {
		if (this.getDirection() == Direction.LEFT) {
			gc.strokeOval(this.getWidth() / 8, this.getHeight() / 6, this.getWidth() / 8, this.getHeight() / 8);
			gc.fillOval(this.getWidth() / 8, this.getHeight() / 6, this.getWidth() / 8, this.getHeight() / 8);
		} else {
			gc.strokeOval(this.getWidth() - this.getWidth() / 4, this.getHeight() / 6, this.getWidth() / 8, this.getHeight() / 8);
			gc.fillOval(this.getWidth() - this.getWidth() / 4, this.getHeight() / 6, this.getWidth() / 8, this.getHeight() / 8);
		}
	}

	private void setBlackFillAndStroke(GraphicsContext gc) {
		gc.setFill(Color.BLACK);
		gc.setStroke(Color.BLACK);
	}

	private void drawFin(GraphicsContext gc) {
		this.drawLeftSideOfFin(gc);
		this.drawRightSideOfFin(gc);
	}

	private void drawRightSideOfFin(GraphicsContext gc) {
		double startXPos = this.getWidth() / 2;
		double startYPos = this.getHeight() / 2 + 5;
		double endXPos = startXPos + (this.getWidth() / 8);
		double endYPos = startYPos - (this.getHeight() / 8);
		
		gc.strokeLine(startXPos, startYPos, endXPos, endYPos);
	}

	private void drawLeftSideOfFin(GraphicsContext gc) {
		double startXPos = this.getWidth() / 2;
		double startYPos = this.getHeight() / 2 + 5;
		double endXPos = startXPos - (this.getWidth() / 8);
		double endYPos = startYPos - (this.getHeight() / 8);
		
		gc.strokeLine(startXPos, startYPos, endXPos, endYPos);
	}

	private void drawMouth(GraphicsContext gc) {
		if (this.getDirection() == Direction.RIGHT) {
			double startXPos = this.getWidth();
			double endXPos = this.getWidth() - (this.getWidth() / 8);
			double yPos = this.getHeight() / 2;
			
			gc.strokeLine(startXPos, yPos, endXPos, yPos);
		} else {
			double startXPos = 0;
			double yPos = this.getHeight() / 2;
			double endXPos = 0 + (this.getWidth() / 8);
			
			gc.strokeLine(startXPos, yPos, endXPos, yPos);
		}
	}

	private void drawBody(GraphicsContext gc) {
		gc.setStroke(color);
		gc.setFill(color);
		gc.strokeOval(0, 0, this.getWidth(), this.getHeight());
		gc.fillOval(0, 0, this.getWidth(), this.getHeight());
	};
	
	public void moveFishFin() {
		
	}
	
	public void swim() {
		if (this.direction == Direction.RIGHT) {
			this.setLayoutX(this.getLayoutX() + speed);
			if (this.getLayoutX() > Tank.WIDTH) {
				this.setLayoutX(0);
			}
		} else {
			this.setLayoutX(this.getLayoutX() - speed);
			if (this.getLayoutX() + this.getWidth() < 0) {
				this.setLayoutX(Tank.WIDTH);
			}
		}
	}
/**
 * Gets the color of the fish.
 * 
 * @precondition none
 * @postcondition none
 * 
 * @return Color is the color of the fish.
 */
	public Color getColor() {
		return this.color;
	}
}

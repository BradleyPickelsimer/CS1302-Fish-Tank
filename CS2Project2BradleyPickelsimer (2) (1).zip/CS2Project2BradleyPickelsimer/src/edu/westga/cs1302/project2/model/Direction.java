package edu.westga.cs1302.project2.model;

public enum Direction {
LEFT, RIGHT
}

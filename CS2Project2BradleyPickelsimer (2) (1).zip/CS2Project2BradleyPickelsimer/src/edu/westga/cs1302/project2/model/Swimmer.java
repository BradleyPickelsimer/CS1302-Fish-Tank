package edu.westga.cs1302.project2.model;

public interface Swimmer {

	public abstract void swim();
}

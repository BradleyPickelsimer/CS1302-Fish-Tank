package edu.westga.cs1302.project2.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 * The Tank class models a fish tank
 * 
 * @author	CS1302
 * @version Spring 2022
 */
public class Tank extends Rectangle implements Iterable<Swimmer> {
	
	public static final int WIDTH = 750;
	public static final int HEIGHT = 450;
	private List<Fish> fishList;
	
	/**
	 * Instantiates a new tank with no items inside
	 * 
	 * @precondition none
	 * @postcondition fishCollection.size() == 0 && bubbleCollection.size() == 0
	 */
	public Tank() {
		super(0, 0, Tank.WIDTH, Tank.HEIGHT);
		this.setFill(Color.ALICEBLUE);
		this.fishList = new ArrayList<Fish>();
	}
	
	/**
	 * Returns a list of fish in the tank
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return List is the list of fish in the tank
	 */
	public List<Fish> getFish() {
		return this.fishList;
	}
	
	/**
	 * Adds a fish to the tank
	 * 
	 * @precondition none
	 * @postcondition this.fish.size == this.fish.size @ prev + 1
	 * 
	 * @param fish is the fish to be added to the tank
	 */
	public void addFish(Fish fish) {
		this.fishList.add(fish);
	}
	
	/**
	 * Sorts the fish by width in ascending order
	 * 
	 * @precondition none
	 * @postcondition the list of fish in ascending order according to width
	 * 
	 */
	
	public void sortByWidth() {
		Collections.sort(this.fishList);
	}

	@Override
	public Iterator<Swimmer> iterator() {
		return null;
	}
}

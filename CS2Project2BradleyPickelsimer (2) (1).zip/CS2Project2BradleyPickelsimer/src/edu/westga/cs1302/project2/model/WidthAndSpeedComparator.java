package edu.westga.cs1302.project2.model;

public class WidthAndSpeedComparator {

}

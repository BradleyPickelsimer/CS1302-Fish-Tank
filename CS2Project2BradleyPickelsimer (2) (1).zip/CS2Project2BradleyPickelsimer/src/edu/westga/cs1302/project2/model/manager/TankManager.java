package edu.westga.cs1302.project2.model.manager;

import java.util.Random;

import edu.westga.cs1302.project2.model.ElongatedFish;
import edu.westga.cs1302.project2.model.Fish;
import edu.westga.cs1302.project2.model.RoundFish;
import edu.westga.cs1302.project2.model.Tank;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

/**
 * The TankManager class manages the items included in the fish tank
 * 
 * @author	CS1302
 * @version Spring 2022
 */

public class TankManager extends Pane {

	private Tank theTank;
	
	/**
	 * Instantiates a new tank.
	 * 
	 * @precondition none
	 * @postcondition getTank() != null
	 */
	public TankManager() {
		this.theTank = new Tank();
		this.getChildren().add(this.theTank);
	}

	/**
	 * Gets the tank.
	 *
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the tank object
	 */
	public Tank getTank() {
		return this.theTank;
	}
	
	/**
	 * Sets the up fish and bubbles.
	 * 
	 * @precondition numberOfFish >= 0
	 * @postcondition getTank().getFish().getSize() == numberOfFish
	 */
	public void setupTank() {
		this.createFish();
		this.createBubbles();
	}
	
	/**
	 * Generate the fish for the tank.
	 */
	private void createFish() {
		for (int i = 0; i < 9; i++) {
			double nextFish = Math.random();
			if (nextFish < 0.5) {
				RoundFish roundFish = drawRoundFish();
				this.theTank.addFish(roundFish);
				this.getChildren().add(roundFish);
			} else {
				ElongatedFish longFish = drawLongFish();
				this.theTank.addFish(longFish);
				this.getChildren().add(longFish);
			}
		}
	}

	private RoundFish drawRoundFish() {
		double width = Math.random() * (80 - 40) + 40;
		double height = width;
		this.setLayoutX(Math.random() * ((Tank.WIDTH - width) - 0) + 0);
		this.setLayoutY(Math.random() * ((Tank.HEIGHT - height) - 0) + 0);
		double speed = Math.random() * (25 - 5) + 5;
		Color color = Color.color(Math.random(), Math.random(), Math.random());
		RoundFish roundFish = new RoundFish(this.getLayoutX(), this.getLayoutY(), width, height, speed, color);
		roundFish.draw();
		return roundFish;
	}
	
	private ElongatedFish drawLongFish() {
		double width = Math.random() * (80 - 40) + 40;
		double height = 20;
		this.setLayoutX(Math.random() * ((Tank.WIDTH - width) - 0) + 0);
		this.setLayoutY(Math.random() * ((Tank.HEIGHT - height) - 0) + 0);
		double speed = Math.random() * (25 - 5) + 5;
		Color color = Color.color(Math.random(), Math.random(), Math.random());
		ElongatedFish longFish = new ElongatedFish(this.getLayoutX(), this.getLayoutY(), width, height, speed, color);
		longFish.draw();
		return longFish;
	}
	
	/**
	 * Generate bubbles for the tank.
	 */
	private void createBubbles() {
		
	}
	
	/**
	 * Move all swimming objects in the tank
	 *  
	 * @precondition none
	 * @postcondition none
	 */
	public void update() {
		for (Fish fish : this.theTank.getFish()) {
			fish.draw();
			fish.swim();
		}
	}
}

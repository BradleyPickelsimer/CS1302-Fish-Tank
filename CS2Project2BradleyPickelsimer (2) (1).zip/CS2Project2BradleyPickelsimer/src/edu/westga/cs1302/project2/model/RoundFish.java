package edu.westga.cs1302.project2.model;


import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * Defines a round fish
 * @author Bradley Pickelsimer
 * @version 1.0
 */
public class RoundFish extends Fish {

	/**
	 * Instantiates a round fish object with the given parameters.
	 * 
	 * @precondition none
	 * @postcondition A new round fish is created with the given  characteristics
	 * 
	 * @param x the xPos of the fish
	 * @param y the yPos of the fish
	 * @param width the width of the canvas
	 * @param height the height of the canvas
	 * @param color is the color of the fish
	 */
	public RoundFish(double x, double y, double width, double height, double speed, Color color) {
		super(x, y, width, height, speed, color);
		this.draw();
	}

	@Override
	public void draw() {
		super.draw();
	}
	
	/**
	 * Returns the characteristics of the fish in the form of a string
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return String is the characteristics of the fish
	 */
	public String toString() {
		return "RoundFish width=" + this.getWidth() + " color=" + this.color + System.lineSeparator();
	}

	@Override
	public int compareTo(Fish otherFish) {
		if (this.getWidth() < otherFish.getWidth()) {
			return -1;
		} else if (this.getWidth() > otherFish.getWidth()) {
			return 1;
		} else {
			return 0;
		}
	}
}
